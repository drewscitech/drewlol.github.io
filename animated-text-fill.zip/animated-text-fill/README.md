# Animated text fill

A Pen created on CodePen.io. Original URL: [https://codepen.io/Drew-Hertzbach/pen/XWyeZrQ](https://codepen.io/Drew-Hertzbach/pen/XWyeZrQ).

Fill your text with animated background images - no Javascript required, Webkit only.